# Revision History {#rev_hist}

CMSIS-DSP version is offically updated upon releases of the [CMSIS-DSP pack](https://www.keil.arm.com/packs/cmsis-dsp-arm/versions/).

The table below provides information about the changes delivered with specific versions of CMSIS-DSP.
